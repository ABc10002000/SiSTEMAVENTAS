
package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class VendedorDAO {
    PreparedStatement ps;
    ResultSet rs;
    
    ConexionBD con=new ConexionBD();
    Connection acceso;
    
    public EntidadVendedor ValidarVendedor(String DNI , String usuario){
        EntidadVendedor ev = new EntidadVendedor();
        String sql = "slecy * from vendedor where DNI=? and USUARIOS?";
        try{
            acceso=con.Conectar();
            ps=acceso.prepareStatement(sql);
            ps.setString(1, DNI);
            ps.setString(2,usuario);
            while(rs.next()){
                ev.setId(rs.getInt(1));
                ev.setDNI(rs.getString(2));
                ev.setNom(rs.getString(3));
                ev.setCel(rs.getString(4));
                ev.setEstado(rs.getString(5));
                ev.setUsuario(rs.getString(6));
            }
            
            
        }catch(Exception e){
            
        }
        return ev;
        
    }
    
    
}

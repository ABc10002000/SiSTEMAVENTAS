
package Modelo;


public class DetalleVentas {
    int id;
    int idventas;
    int idproducto;
    int cantidad;
    double preventas;

    public DetalleVentas() {
    }

    public DetalleVentas(int id, int idventas, int idproducto, int cantidad, double preventas) {
        this.id = id;
        this.idventas = idventas;
        this.idproducto = idproducto;
        this.cantidad = cantidad;
        this.preventas = preventas;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdventas() {
        return idventas;
    }

    public void setIdventas(int idventas) {
        this.idventas = idventas;
    }

    public int getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(int idproducto) {
        this.idproducto = idproducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPreventas() {
        return preventas;
    }

    public void setPreventas(double preventas) {
        this.preventas = preventas;
    }

    
    
    
    
}


package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class ProductoDAO {
    int r;
    PreparedStatement ps;
    ResultSet rs;
    Connection con;
    ConexionBD acceso= new ConexionBD();
    Producto pro = new Producto();
    
    public int actualizarStock(int cant, int idp){
        String sql="update producto set Stock=? where IdProducto=?";
        try {
            con=acceso.Conectar();
            ps=con.prepareStatement(sql);
            ps.setInt(1, cant);
            ps.setInt(2, idp);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return r;
        
    }
    public Producto listarID(int id){
        Producto p = new Producto();
        String sql="select * from productp where IdProducto";
        try {
            con=acceso.Conectar();
            ps=con.prepareStatement(sql);
            ps.setInt(1, id);
            rs=ps.executeQuery();
            while(rs.next()){
                p.setId(rs.getInt(1));
                p.setNom(rs.getString(2));
                p.setPrecio(rs.getDouble(3));
                p.setStock(rs.getInt(4));
                p.setEstado(rs.getString(5));
                
            }
        } catch (Exception e) {
        }
        return p;
    }
    
}

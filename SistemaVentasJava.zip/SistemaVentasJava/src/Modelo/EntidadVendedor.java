
package Modelo;

public class EntidadVendedor {
     int id;
     String DNI;
     String nom;
     String cel;
     String estado;
     String usuario;

    public EntidadVendedor() {
    }

    public EntidadVendedor(int id, String DNI, String nom, String cel, String estado, String usuario) {
        this.id = id;
        this.DNI = DNI;
        this.nom = nom;
        this.cel = cel;
        this.estado = estado;
        this.usuario = usuario;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCel() {
        return cel;
    }

    public void setCel(String cel) {
        this.cel = cel;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
     
    
}

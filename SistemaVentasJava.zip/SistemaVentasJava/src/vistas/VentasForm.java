/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vistas;



import Modelo.Cliente;
import Modelo.ClienteDAO;
import Modelo.DetalleVentas;
import Modelo.Producto;
import Modelo.ProductoDAO;
import Modelo.VentaDAO;
import Modelo.Ventas;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author delac
 */
public class VentasForm extends javax.swing.JInternalFrame {
    
    ClienteDAO cdac=new ClienteDAO();
    VentaDAO vdao= new VentaDAO();
    ProductoDAO prod= new ProductoDAO();
    Producto p= new Producto();
    Ventas v= new Ventas();
    DetalleVentas dv= new DetalleVentas();
    
    Cliente cliente = new Cliente();
            

   
    DefaultTableModel modelo= new DefaultTableModel();
    int idp;
    int cant;
    double pre;
    double tpagar;
    
    
    public VentasForm() {
        initComponents();
        
        Calendar calendar = new GregorianCalendar();
        jfecha.setText(""+calendar.get(Calendar.YEAR)+"-"+calendar.get(Calendar.MONTH)+"-"+calendar.get(Calendar.DAY_OF_MONTH));
        
        
        
    }
    

   
        
    
    

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jserie = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jcodcliente = new javax.swing.JTextField();
        jcodproduc = new javax.swing.JTextField();
        jprecio = new javax.swing.JTextField();
        jcantidad = new javax.swing.JSpinner();
        jbuscarcñ = new javax.swing.JButton();
        jbuscarcn = new javax.swing.JButton();
        jagregar = new javax.swing.JButton();
        jfecha = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jcliente = new javax.swing.JTextField();
        jproducto = new javax.swing.JTextField();
        jstock = new javax.swing.JTextField();
        jvende = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtabladetalle = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jtotal = new javax.swing.JTextField();
        jgenerar = new javax.swing.JButton();
        jcancelar = new javax.swing.JButton();

        setTitle("Sistema de Ventas");

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Verdana", 3, 18)); // NOI18N
        jLabel1.setText("PUNTO DE VENTAS \"VENTA-NET\"");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/Imagen de WhatsApp 2023-11-30 a las 00.19.35_d0e03c05 (2).jpg"))); // NOI18N

        jLabel3.setText("Venta De Productos");

        jLabel4.setText("Telf: 017899563");

        jLabel5.setText("NRO SERIE:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(68, 68, 68)
                                .addComponent(jLabel1))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(193, 193, 193)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(246, 246, 246)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jserie, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jserie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel6.setText("COD: CLIENTE:");

        jLabel7.setText("COD: PRODU:");

        jLabel8.setText("PRECIO:");

        jLabel9.setText("CANTIDAD");

        jbuscarcñ.setText("BUSCAR");
        jbuscarcñ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbuscarcñActionPerformed(evt);
            }
        });

        jbuscarcn.setText("BUSCAR");
        jbuscarcn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbuscarcnActionPerformed(evt);
            }
        });

        jagregar.setText("AGREGAR");
        jagregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jagregarActionPerformed(evt);
            }
        });

        jLabel10.setText("CLIENTE:");

        jLabel11.setText("PRODUC:");

        jLabel12.setText("STOCK:");

        jLabel13.setText("VENDE:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jcodcliente)
                    .addComponent(jcodproduc)
                    .addComponent(jprecio)
                    .addComponent(jcantidad, javax.swing.GroupLayout.DEFAULT_SIZE, 119, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jagregar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jbuscarcn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jbuscarcñ, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jfecha))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jcliente))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jproducto))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(18, 18, 18)
                        .addComponent(jvende))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGap(18, 18, 18)
                        .addComponent(jstock)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jcodcliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbuscarcñ)
                    .addComponent(jLabel10)
                    .addComponent(jcliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jcodproduc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbuscarcn)
                    .addComponent(jLabel11)
                    .addComponent(jproducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jprecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jagregar)
                    .addComponent(jLabel12)
                    .addComponent(jstock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jcantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jfecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(jvende, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 17, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jtabladetalle.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NRO", "COD", "PRODUCTO", "CANTIDAD", "PRECIO UNI", "TOTAL"
            }
        ));
        jScrollPane1.setViewportView(jtabladetalle);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 593, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 243, Short.MAX_VALUE)
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel14.setText("TOTAL:");

        jgenerar.setText("GENERAR VENTA");
        jgenerar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jgenerarActionPerformed(evt);
            }
        });

        jcancelar.setText("CANCELAR");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jcancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jgenerar, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(jtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jgenerar)
                    .addComponent(jcancelar))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbuscarcñActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbuscarcñActionPerformed
      
        buscarCliente();
    }//GEN-LAST:event_jbuscarcñActionPerformed

    private void jbuscarcnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbuscarcnActionPerformed
        // TODO add your handling code here:
        buscarProducto();
    }//GEN-LAST:event_jbuscarcnActionPerformed

    private void jagregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jagregarActionPerformed
        // TODO add your handling code here:
        agregarProducto();
        
    }//GEN-LAST:event_jagregarActionPerformed

    private void jgenerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jgenerarActionPerformed
        // TODO add your handling code here:
        if(jtotal.getText().equals("")){
            JOptionPane.showMessageDialog(this, "DEBE INGRESAR DATOS");
            
            
            
        }else{
        guardarVenta();
        guardarDetalle();
        actualizarStock();
        JOptionPane.showMessageDialog(this, "SE REALIZO CON EXITO");   
        nuevo();
        }
        
        
    }//GEN-LAST:event_jgenerarActionPerformed

    void nuevo(){
        limpiarTabla();
        jcodcliente.setText("");
        jcliente.setText("");
        jcantidad.setValue(1);
        jcodproduc.setText("");
        jprecio.setText("");
        jproducto.setText("");
        jstock.setText("");
        jtotal.setText("");
        jcliente.requestFocus();
        
    }
    void limpiarTabla(){
        for (int i = 0; i < jtabladetalle.getRowCount(); i++) {
            modelo.removeRow(i);
            i=i-1;
            
            
            
        }
    }
    void actualizarStock(){
        for (int i = 0; i < modelo.getRowCount(); i++) {
            Producto pr= new Producto();
            idp=Integer.parseInt(jtabladetalle.getValueAt(i, 1).toString());
            cant=Integer.parseInt(jtabladetalle.getValueAt(i, 3).toString());
            pr=prod.listarID(idp);
            int sa=pr.getStock()- cant;
            prod.actualizarStock(sa, idp);
            
            
        }
        
        
    }
    
    void guardarVenta(){
        int idv=1;
        int idc=cliente.getId();
        String serie=jserie.getText();
        String fecha=jfecha.getText();
        double monto=tpagar;
        String estado="1";
        
        v.setIdcliente(idc);
        v.setIdvendedor(idv);
        v.setSerie(serie);
        v.setFecha(fecha);
        v.setMonto(monto);
        v.setEstado(estado);
        vdao.GuardarVentas(v);
        
        
        
    }
    void guardarDetalle(){
        String idv=vdao.IdVentas();
        int idvc=Integer.parseInt(idv);
        for (int i = 0; i < jtabladetalle.getRowCount(); i++) {
            int idp=Integer.parseInt(jtabladetalle.getValueAt(i, 1).toString());
            int cant=Integer.parseInt(jtabladetalle.getValueAt(i, 3).toString());
            double pre=Double.parseDouble(jtabladetalle.getValueAt(1, 4).toString());
            dv.setIdventas(idvc);
            dv.setIdproducto(idp);
            dv.setCantidad(cant);
            dv.setPreventas(pre);
            vdao.GuardarDetalleVentas(dv);
        }
        
    }
    void agregarProducto(){
        double total;
        int item=0;
        modelo=(DefaultTableModel)jtabladetalle.getModel();
        item=item+1;
        idp=p.getId();
        String nomp=jproducto.getText();
        pre= Double.parseDouble(jprecio.getText());
        cant= Integer.parseInt(jcantidad.getValue().toString());
        int stock=Integer.parseInt(jstock.getText());
        total=cant*pre;
        ArrayList lista= new ArrayList();
        if(stock>0){
            lista.add(item);
            lista.add(idp);
            lista.add(nomp);
            lista.add(pre);
            lista.add(cant);
            lista.add(total);
            Object[] ob=new Object[6];
            ob[0]=lista.get(0);
            ob[1]=lista.get(1);
            ob[2]=lista.get(2);
            ob[3]=lista.get(3);
            ob[4]=lista.get(4);
            ob[5]=lista.get(5);
            modelo.addRow(ob);
            jtabladetalle.setModel(modelo);
            calcularTotal();
        }else{
            JOptionPane.showMessageDialog(this, "Stock Producto no Disponible");
        }
   
    }
    void calcularTotal(){
        tpagar=0;
        for (int i = 0; i < jtabladetalle.getRowCount(); i++){ 
            cant=Integer.parseInt(jtabladetalle.getValueAt(i, 3).toString());
            pre=Double.parseDouble(jtabladetalle.getValueAt(i, 4).toString());
            tpagar=tpagar+cant*pre;
        }
        jtotal.setText(""+tpagar+"0");
        
        
        
        
        
        
    }
    void buscarProducto(){
        int id=Integer.parseInt(jcodproduc.getText());
        if(jcodproduc.getText().equals("")){
            JOptionPane.showConfirmDialog(this,"Debe ingresar Codigo del Producto");
            
        }else{
            Producto p=prod.listarID(id);
            if(p.getId() !=0){
                jproducto.setText(p.getNom());
                jprecio.setText(""+p.getPrecio());
                jstock.setText(""+p.getStock());
                
                
                
            }else{
                JOptionPane.showConfirmDialog(this, "Producto no Registrado");
                jcodproduc.requestFocus();
            }
            
        }
        
        
    }
    void buscarCliente(){
        int r;
        String cod=jcodcliente.getText();
        if(jcodcliente.getText().equals("")){
            JOptionPane.showConfirmDialog(this, "Debe ingresar Cod Cliente");
        }else{
            cliente=cdac.listarID(cod);
            if(cliente.getDNI() !=null){
                jcliente.setText(cliente.getNom());
                jcodproduc.requestFocus();
                
                
            }else{
                r=JOptionPane.showConfirmDialog(this, "Cliente No Registrado,Desea Registrar");
                if(r==0){
                    ClienteForm cf=new ClienteForm();
                    Principal.VentanaPrincipal.add(cf);
                    cf.setVisible(true);
                }
                
            }
                    
            
            
            
        }
        
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jagregar;
    private javax.swing.JButton jbuscarcn;
    private javax.swing.JButton jbuscarcñ;
    private javax.swing.JButton jcancelar;
    private javax.swing.JSpinner jcantidad;
    private javax.swing.JTextField jcliente;
    private javax.swing.JTextField jcodcliente;
    private javax.swing.JTextField jcodproduc;
    private javax.swing.JTextField jfecha;
    private javax.swing.JButton jgenerar;
    private javax.swing.JTextField jprecio;
    private javax.swing.JTextField jproducto;
    private javax.swing.JTextField jserie;
    private javax.swing.JTextField jstock;
    private javax.swing.JTable jtabladetalle;
    private javax.swing.JTextField jtotal;
    private javax.swing.JTextField jvende;
    // End of variables declaration//GEN-END:variables
}
